//============================================================================
// Name        : Rush Hour Game
// Author      : Dr. Sibt Ul Hussain
// Version     :
// Copyright   : (c) Reserved
// Description : Basic 2D game...
//============================================================================

#ifndef RushHour_CPP_
#define RushHour_CPP_
#include "util.h"
#include <iostream>
#include <fstream>
#include <string>
#include <cmath> // for basic math functions such as cos, sin, sqrt
#include <cstdlib> // for random number generation
#include <ctime> // for seeding random number generator
using namespace std;

float gameTime = 0; // Total time elapsed in seconds
string userName = ""; // Input for player's name
string driverRole = ""; // Player's role: Taxi Driver / Delivery Driver / Random
bool nameInputComplete = false; // Flag to check if name has been entered
bool roleChosen = false; // Flag to check if role has been selected
bool gameElementsInitialized = false; // Elements to be placed randomly only once.
const int INITIAL_FUEL = 1000; // For slower consumption of fuel
const int FUEL_BAR_WIDTH = 200;
const int FUEL_BAR_HEIGHT = 20; // Dimensions of fuel bar
const int FUEL_BAR_X = 1300;
const int FUEL_BAR_Y = 1150;
bool nearFuelStation = false; // Flag to track if player is near a fuel station

// Drop off variables
bool hasPassenger = false; // Flag to track if taxi has a passenger
bool hasDelivery = false; // Flag to track if delivery driver has a package
int currentPassengerIndex = -1; // Index of current passenger being carried
int currentDeliveryIndex = -1; // Index of current delivery being carried
int destinationX = -1, destinationY = -1; // Destination coordinates for dropoff
float pickupTime = 0; // Time when passenger/delivery was picked up
const float MAX_DELIVERY_TIME = 30.0f; // Max time allowed for delivery (30 seconds)

const int NPC_MOVE_SPEED = 3; // Speed of NPC movement
double earnings = 0; // Variable to track player's earnings

// Collision effect variables
bool collisionEffectActive = false; // Flag to indicate if collision effect is active
int collisionEffectDuration = 0; // Timer for collision effect duration
const int COLLISION_EFFECT_TIME = 5; // Duration of the effect in frames

// Refueling variables
bool isRefueling = false; // Flag to indicate if the car is refueling

// Define building boundaries for collision detection
struct Building {
    int x, y, width, height;
};

Building buildings[] = {
    {230, 970, 50, 150},
    {200, 920, 200, 70},
    {200, 350, 150, 250},
    {530, 260, 400, 50},
    {1320, 350, 280, 50},
    {730, 600, 50, 100},
    {1050, 170, 60, 600},
    {250, 0, 50, 120},
    {700, 0, 50, 120},
    {1450, 0, 50, 120},
    {460, 450, 75, 400},
    {600, 920, 1000, 70},
    {1050, 500, 300, 70}
};
const int NUM_BUILDINGS = sizeof(buildings) / sizeof(buildings[0]);

bool checkBuildingCollision(int x, int y) {
    int objectWidth = 50, objectHeight = 25;

    // Collision check with buildings
    for (int i = 0; i < NUM_BUILDINGS; i++) {
        if (x < buildings[i].x + buildings[i].width &&
            x + objectWidth > buildings[i].x &&
            y < buildings[i].y + buildings[i].height &&
            y + objectHeight > buildings[i].y) {
            return true; // Collision with building
        }
    }
    return false;
}

bool checkScreenBoundary(int x, int y) {
    int objectWidth = 50, objectHeight = 25;
    return (x < 10 || x + objectWidth > 1590 || y < 10 || y + objectHeight > 1110);
}

// Function to check collision between two objects
bool checkObjectCollision(int x1, int y1, int width1, int height1, int x2, int y2, int width2, int height2) {
    return (x1 < x2 + width2 &&
            x1 + width1 > x2 &&
            y1 < y2 + height2 &&
            y1 + height1 > y2);
}

struct DeliveryPickup {
    int x, y; // Position of the delivery pickup
};

struct FuelStation {
    int x, y; // Position of the fuel station
};

class GameEntity { // Inheritance, Polymorphism, and Abstraction
protected:
    int x, y; // Position
    int dirX, dirY; // Direction
public:
    GameEntity(int posX = -1, int posY = -1, int dx = 0, int dy = 0) : x(posX), y(posY), dirX(dx), dirY(dy) {
    }
    virtual ~GameEntity() {
    } // Virtual destructor for safe inheritance
    
    int getX() const { 
    return x; 
    }
    
    int getY() const { 
    return y; 
    }
    
    int getDirX() const {
    return dirX; 
    }
    
    int getDirY() const { 
    return dirY; 
    }
    
    void setPositionX(int newX) { 
    x = newX; 
    }
    
    void setPositionY(int newY) {
    y = newY;
    }
    
    void setDirectionX(int newDirX) {
     dirX = newDirX; 
     }
     
    void setDirectionY(int newDirY) {
     dirY = newDirY;
     }
     
     virtual void render() const = 0; // Pure virtual render method
};

class Car : public GameEntity {
public:
    Car(int posX = -1, int posY = -1, int dx = 0, int dy = 0) : GameEntity(posX, posY, dx, dy) {
    }
    
    void render() const override { // Polymorphism
        // Car body
        DrawRectangle(x, y, 50, 25, colors[BLUE]); // Car body
        // Wheels
        DrawCircle(x + 10, y - 5, 5, colors[BLACK]); // Left wheel
        DrawCircle(x + 40, y - 5, 5, colors[BLACK]); // Right wheel
    }
};

class Passenger : public GameEntity {
public:
    Passenger(int posX = -1, int posY = -1, int dx = 0, int dy = 0) : GameEntity(posX, posY, dx, dy) {
    }
    
    void render() const override { // Polymorphism
        if (x != -1) { // Only render if passenger is valid
            // Draw stick figure
            DrawCircle(x + 15, y + 30, 8, colors[BLACK]); // Head
            DrawLine(x + 15, y + 25, x + 15, y + 10, 3, colors[BLACK]); // Body
            DrawLine(x + 15, y + 20, x + 5, y + 20, 3, colors[BLACK]); // Left arm
            DrawLine(x + 15, y + 20, x + 25, y + 20, 3, colors[BLACK]); // Right arm
            DrawLine(x + 15, y + 10, x + 5, y, 3, colors[BLACK]); // Left leg
            DrawLine(x + 15, y + 10, x + 25, y, 3, colors[BLACK]); // Right leg
        }
    }
};

struct Tree {
    int x, y; // Position of the tree
};

struct Garage {
    int x, y; // Position of the garage
};

struct PassengerDestination {
    int x, y; // Position of the destination
};

struct DeliveryDestination {
    int x, y; // Position of the destination
};

const int MAX_CARS = 5; // Maximum number of cars
const int MAX_TREES = 5; // Maximum number of trees
const int MAX_DELIVERIES = 3;
const int MAX_FUEL_STATIONS = 3;
const int MAX_PASSENGERS = 5;

DeliveryPickup deliveries[MAX_DELIVERIES];
FuelStation fuelStations[MAX_FUEL_STATIONS];
Car cars[MAX_CARS]; // Array to hold car objects
Passenger passengers[MAX_PASSENGERS]; // Array to hold passenger objects
Tree trees[MAX_TREES]; // Array to hold tree positions
Garage garage; // Garage object
PassengerDestination passengerDestinations[MAX_PASSENGERS];
DeliveryDestination deliveryDestinations[MAX_DELIVERIES];

bool isPositionValid(int x, int y, int width, int height) {
    // Check for collision with buildings and screen boundaries
    if (checkScreenBoundary(x, y) || checkBuildingCollision(x, y)) {
        return false;
    }

    // Check for collision with other cars
    for (int i = 0; i < MAX_CARS; i++) {
        if (cars[i].getX() != -1 && checkObjectCollision(x, y, width, height, cars[i].getX(), cars[i].getY(), 50, 25)) {
            return false;
        }
    }

    // Check for collision with trees
    for (int i = 0; i < MAX_TREES; i++) {
        if (trees[i].x != -1 && checkObjectCollision(x, y, width, height, trees[i].x, trees[i].y, 20, 40)) {
            return false;
        }
    }

    // Check for collision with delivery pickups
    for (int i = 0; i < MAX_DELIVERIES; i++) {
        if (deliveries[i].x != -1 && checkObjectCollision(x, y, width, height, deliveries[i].x, deliveries[i].y, 40, 40)) {
            return false;
        }
    }

    // Check for collision with fuel stations
    for (int i = 0; i < MAX_FUEL_STATIONS; i++) {
        if (fuelStations[i].x != -1 && checkObjectCollision(x, y, width, height, fuelStations[i].x, fuelStations[i].y, 30, 60)) {
            return false;
        }
    }

    // Check for collision with passengers
    for (int i = 0; i < MAX_PASSENGERS; i++) {
        if (passengers[i].getX() != -1 && checkObjectCollision(x, y, width, height, passengers[i].getX(), passengers[i].getY(), 30, 30)) {
            return false;
        }
    }

    // Check for collision with garage
    if (garage.x != -1 && checkObjectCollision(x, y, width, height, garage.x, garage.y, 60, 60)) {
        return false;
    }

    return true;
}

void InitializeGameElements() {
    srand(time(0)); // Seed random number generator

    // Defining the y-coordinate limit for placement (below the info bar)
    const int INFO_BAR_Y = 1120; // Y-coordinate of the info bar line
    const int MIN_Y = 50; // Minimum y-coordinate to stay away from bottom edge
    const int MAX_Y = INFO_BAR_Y - 100; // Maximum y-coordinate to stay below info bar

    // Initialize arrays with invalid positions
    for (int i = 0; i < MAX_CARS; i++) cars[i].setPositionX(-1); // Inheritance
    for (int i = 0; i < MAX_TREES; i++) trees[i].x = -1;
    for (int i = 0; i < MAX_DELIVERIES; i++) deliveries[i].x = -1;
    for (int i = 0; i < MAX_FUEL_STATIONS; i++) fuelStations[i].x = -1;
    for (int i = 0; i < MAX_PASSENGERS; i++) passengers[i].setPositionX(-1); // Inheritance
    garage.x = -1;

    // Place garage in one of the corners
    int garageCorner = rand() % 3; // Randomly choose a corner (0: bottom-left, 1: bottom-right, 2: top-right)
    switch (garageCorner) {
    case 0: // Bottom-left corner
        garage.x = 50; 
        garage.y = MIN_Y;
        break;
    case 1: // Bottom-right corner
        garage.x = 1550; 
        garage.y = MIN_Y;
        break;
    case 2: // Top-right corner
        garage.x = 1550; 
        garage.y = MAX_Y;
        break;
    }

    // Randomly place delivery pickups
    for (int i = 0; i < MAX_DELIVERIES; i++) {
        int x, y;
        do {
            x = rand() % 1550 + 50; // Random x position
            y = MIN_Y + rand() % (MAX_Y - MIN_Y); // Random y position safely below info bar
        } while (!isPositionValid(x, y, 40, 40));
        deliveries[i].x = x;
        deliveries[i].y = y;
    }
    
    // After initializing deliveries, add their destinations
    for (int i = 0; i < MAX_DELIVERIES; i++) {
        if (deliveries[i].x != -1) { // If delivery exists
            int x, y;
            do {
                x = rand() % 1550 + 50; // Random x position
                y = MIN_Y + rand() % (MAX_Y - MIN_Y); // Random y position
                // Ensure destination is not too close to pickup location and valid
            } while (!isPositionValid(x, y, 40, 40) || 
                     abs(x - deliveries[i].x) < 200 || 
                     abs(y - deliveries[i].y) < 200);
            deliveryDestinations[i].x = x;
            deliveryDestinations[i].y = y;
        }
    }

    // Randomly place fuel stations
    for (int i = 0; i < MAX_FUEL_STATIONS; i++) {
        int x, y;
        do {
            x = rand() % 1550 + 50; // Random x position
            y = MIN_Y + rand() % (MAX_Y - MIN_Y); // Random y position
        } while (!isPositionValid(x, y, 30, 60));
        fuelStations[i].x = x;
        fuelStations[i].y = y;
    }

    // Randomly place passengers (for both Taxi Driver and Delivery Driver roles)
    for (int i = 0; i < MAX_PASSENGERS; i++) {
        int x, y;
        do {
            x = rand() % 1550 + 50; // Random x position
            y = 50 + rand() % (1120 - 100); // Random y position safely below info bar
        } while (!isPositionValid(x, y, 30, 30));
        passengers[i].setPositionX(x); // Inheritance
        passengers[i].setPositionY(y); // Inheritance
        passengers[i].setDirectionX((rand() % 3) - 1); // -1, 0, or 1 (Inheritance)
        passengers[i].setDirectionY((rand() % 3) - 1); // -1, 0, or 1
        // For ensuring non-zero direction
	while (passengers[i].getDirX() == 0 && passengers[i].getDirY() == 0) {
    	passengers[i].setDirectionX((rand() % 3) - 1); // Inheritance
    	passengers[i].setDirectionY((rand() % 3) - 1);
	}
    }
    
    // After initializing passengers, add their destinations
    for (int i = 0; i < MAX_PASSENGERS; i++) {
        if (passengers[i].getX() != -1) { // If passenger exists (Inheritance)
            int x, y;
            do {
                x = rand() % 1550 + 50; // Random x position
                y = MIN_Y + rand() % (MAX_Y - MIN_Y); // Random y position
                // Ensure destination is not too close to pickup location and valid
            } while (!isPositionValid(x, y, 40, 40) || 
                     abs(x - passengers[i].getX()) < 200 || 
                     abs(y - passengers[i].getY()) < 200);
            passengerDestinations[i].x = x;
            passengerDestinations[i].y = y;
        }
    }
    
    // Reset pickup/dropoff states
    hasPassenger = false;
    hasDelivery = false;
    currentPassengerIndex = -1;
    currentDeliveryIndex = -1;
    destinationX = -1;
    destinationY = -1;

    // Randomly place cars
    for (int i = 0; i < MAX_CARS; i++) {
        int x, y;
        do {
            x = rand() % 1550 + 50; // Random x position
            y = MIN_Y + rand() % (MAX_Y - MIN_Y); // Random y position safely below info bar
        } while (!isPositionValid(x, y, 50, 25));
        cars[i].setPositionX(x); // Inheritance
        cars[i].setPositionY(y); // Inheritance
        cars[i].setDirectionX((rand() % 3) - 1); // -1, 0, or 1 (Inheritance)
        cars[i].setDirectionY((rand() % 3) - 1); // -1, 0, or 1
        // For ensuring non-zero direction
	while (cars[i].getDirX() == 0 & cars[i].getDirY() == 0) {
    	cars[i].setDirectionX((rand() % 3) - 1); // Inheritance
    	cars[i].setDirectionY((rand() % 3) - 1);
	}
    }

    // Randomly place trees
    for (int i = 0; i < MAX_TREES; i++) {
        int x, y;
        do {
            x = rand() % 1550 + 50; // Random x position
            y = MIN_Y + rand() % (MAX_Y - MIN_Y); // Random y position safely below info bar
        } while (!isPositionValid(x, y, 20, 40));
        trees[i].x = x;
        trees[i].y = y;
    }
}

void renderGameElements() {
    // Render fuel stations
    for (int i = 0; i < MAX_FUEL_STATIONS; i++) {
        DrawRectangle(fuelStations[i].x, fuelStations[i].y, 30, 60, colors[RED]);
    }

    // Render delivery packages
    if (driverRole == "Delivery Driver") {
        for (int i = 0; i < MAX_DELIVERIES; i++) {
            if (deliveries[i].x != -1) { // if deliveries exist
                DrawRectangle(deliveries[i].x, deliveries[i].y, 40, 40, colors[BROWN]);
            }
        }
    }

    // Render delivery destinations
    if (driverRole == "Delivery Driver" && hasDelivery && destinationX != -1) {
        DrawRectangle(destinationX, destinationY, 40, 60, colors[BLUE]);
        DrawRectangle(destinationX + 10, destinationY + 60, 20, 10, colors[BLUE]);
    }

    // Render passenger destinations
    if (driverRole == "Taxi Driver" && hasPassenger && destinationX != -1) {
        DrawRectangle(destinationX, destinationY, 30, 50, colors[GREEN]);
        DrawTriangle(destinationX + 15, destinationY + 50, 
                    destinationX, destinationY + 70, 
                    destinationX + 30, destinationY + 70, colors[GREEN]);
    }

    // Render cars and passengers polymorphically
    for (int i = 0; i < MAX_CARS; i++) {
        if (cars[i].getX() != -1) {
            cars[i].render(); // Polymorphic call
        }
    }
    for (int i = 0; i < MAX_PASSENGERS; i++) {
        if (passengers[i].getX() != -1) {
            passengers[i].render(); // Polymorphic call
        }
    }

    // Render trees
    for (int i = 0; i < MAX_TREES; i++) {
        DrawRectangle(trees[i].x, trees[i].y, 20, 40, colors[GREEN]);
        DrawCircle(trees[i].x + 10, trees[i].y + 40, 15, colors[LIGHT_GREEN]);
    }

    // Render garage
    DrawRectangle(garage.x, garage.y, 60, 40, colors[GRAY]);
    
    glBegin(GL_TRIANGLES);
    glColor3f(0.5f, 0.5f, 0.5f);
    glVertex2f(garage.x, garage.y + 40);
    glVertex2f(garage.x + 60, garage.y + 40);
    glVertex2f(garage.x + 30, garage.y + 60);
    glEnd();
}

// Function to set the canvas size (drawing area) in pixels
void SetCanvasSize(int width, int height) {
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, width, 0, height, -1, 1); // Set the screen size to given width and height
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

int vehiclePosX = 30, vehiclePosY = 1050; // Vehicle's initial position at the top left corner

// Function to render the vehicle on the canvas
void renderVehicle() {
    int startX = vehiclePosX, startY = vehiclePosY;
    float vehicleWidth = 50;
    float vehicleHeight = 25;
    float* vehicleColor;
    float* wheelColor = colors[BLACK];
    float wheelRadius = 5.0;

    // Change vehicle color based on state
    if (isRefueling) {
        vehicleColor = colors[GREEN]; // Green when refueling
    } else if (collisionEffectActive) {
        vehicleColor = colors[RED]; // Red on collision
    } else {
        // Normal vehicle colors based on role
        if (driverRole == "Taxi Driver") {
            vehicleColor = colors[YELLOW];
        } else if (driverRole == "Delivery Driver") {
            if (hasDelivery) {
            vehicleColor = colors[ORANGE]; // Orange when carrying a delivery
        } else {
            vehicleColor = colors[WHITE]; // White when no delivery
        }
        } else {
            vehicleColor = colors[BLUE]; // Default color
        }
    }

    // Draw wheels
    DrawRoundRect(startX, startY, vehicleWidth/4, vehicleHeight/2, wheelColor, wheelRadius);
    DrawRoundRect(startX + vehicleWidth * 0.75, startY, vehicleWidth/4, vehicleHeight/2, wheelColor, wheelRadius);
    DrawRoundRect(startX + vehicleWidth * 0.75, startY + vehicleHeight * 0.5, vehicleWidth/4, vehicleHeight/2, wheelColor, wheelRadius);
    DrawRoundRect(startX, startY + vehicleHeight * 0.5, vehicleWidth/4, vehicleHeight/2, wheelColor, wheelRadius);

    // Draw vehicle body
    DrawRectangle(startX + vehicleWidth/4, startY + vehicleHeight/2, 
                vehicleWidth/2, vehicleHeight, vehicleColor);

    // Add role-specific details
    if (driverRole == "Taxi Driver") {
        // Taxi sign
        DrawRectangle(startX + vehicleWidth * 0.4, startY + vehicleHeight * 0.8, vehicleWidth * 0.2, vehicleHeight * 0.2, colors[RED]);
    } else if (driverRole == "Delivery Driver") {
        // Delivery package compartment
        DrawRectangle(startX + vehicleWidth * 0.2, startY + vehicleHeight * 0.7, 
                      vehicleWidth * 0.6, vehicleHeight * 0.3, colors[BROWN]);
    }
    if (hasPassenger) {
        DrawCircle(startX + vehicleWidth * 0.5, startY + vehicleHeight * 0.8, 
                  5, colors[BLACK]);
    }
    if (hasDelivery) {
        DrawRectangle(startX + vehicleWidth * 0.3, startY + vehicleHeight * 0.7, 
                     vehicleWidth * 0.4, vehicleHeight * 0.2, colors[BROWN]);
    }

    glutPostRedisplay();
}

void updateVehiclePosition() {
    // Move the vehicle left and right within the screen bounds
    if (vehiclePosX < 10) vehiclePosX = 10; // Prevent moving out of bounds on the left
    if (vehiclePosX > 1550) vehiclePosX = 1550; // Prevent moving out of bounds on the right
    if (vehiclePosY < 10) vehiclePosY = 10; // Prevent moving out of bounds on the top
    if (vehiclePosY > 1110) vehiclePosY = 1110; // Prevent moving out of bounds on the bottom
}

const int MAX_SCORES = 10; // Maximum number of players on the leaderboard

struct ScoreEntry {
    string player; // Player's name
    int score; // Player's score
};

ScoreEntry scoreBoard[MAX_SCORES]; // Array to hold leaderboard entries
int currentScoreCount = 0; // Current number of scores in the leaderboard

// Function to load high scores from a file
void LoadHighScores() {
    ifstream scoreFile("highscores.txt");
    currentScoreCount = 0; // Reset score count

    if (!scoreFile.is_open()) return; // Exit if file cannot be opened

    // Read scores from the file
    while (scoreFile >> scoreBoard[currentScoreCount].player >> scoreBoard[currentScoreCount].score) {
        currentScoreCount++;
        if (currentScoreCount >= MAX_SCORES) break; // Stop if max entries reached
    }

    scoreFile.close(); // Close the file
}

// Function to save high scores to a file
void SaveHighScores() {
    ofstream scoreFile("highscores.txt");

    // Write scores to the file
    for (int i = 0; i < currentScoreCount; i++) {
        scoreFile << scoreBoard[i].player << " " << scoreBoard[i].score << endl;
    }

    scoreFile.close(); // Close the file
}

// Function to add a new high score
void AddHighScore(string playerName, int score) {
    LoadHighScores(); // Load existing high scores

    // Add new score if there's space
    if (currentScoreCount < MAX_SCORES) {
        scoreBoard[currentScoreCount].player = playerName;
        scoreBoard[currentScoreCount].score = score;
        currentScoreCount++;
    } else {
        // Replace the lowest score if the new score is higher
        if (score > scoreBoard[currentScoreCount - 1].score) {
            scoreBoard[currentScoreCount - 1].player = playerName;
            scoreBoard[currentScoreCount - 1].score = score;
        }
    }

    // Sort scores in descending order using bubble sort
    for (int i = 0; i < currentScoreCount - 1; i++) {
        for (int j = i + 1; j < currentScoreCount; j++) {
            if (scoreBoard[j].score > scoreBoard[i].score) {
                ScoreEntry temp = scoreBoard[i];
                scoreBoard[i] = scoreBoard[j];
                scoreBoard[j] = temp;
            }
        }
    }

    SaveHighScores(); // Save updated scores to file
}

class Player {
private:
    string playerName; // Player's name
    int playerScore; // Player's score

public:
    // Constructor
    Player(string name = "Player") {
        playerName = name;
        playerScore = 0; // Initialize score to zero
    }

    int getScore() {
        return playerScore; // Return player's score
    }

    string getName() {
        return playerName; // Return player's name
    }

    // Function to add to score
    void increaseScore(int amount) {
        playerScore += amount; // Increase score by the specified amount
    }

    // Function to reset for a new game
    void reset(string name = "Player") {
        playerName = name; // Reset player's name
        playerScore = 0; // Reset score to zero
    }
};

class TopInfo {
private:
    Player playerInfo; // Composition: Player is fully owned by TopInfo
    int fuel; // Current fuel level
public:
    TopInfo(string playerName = "Player") : playerInfo(playerName) { // Constructor call
        fuel = INITIAL_FUEL; // Set full fuel
    }
    
    int getFuel() { 
        return fuel; 
    }

    // Function to reduce fuel
    void consumeFuel(int amount = 1) { 
        if (fuel > 0) {
            fuel -= amount;
            if (fuel < 0) fuel = 0; // Ensure fuel doesn't go negative
        }
    }

    // Function to refill fuel
    void refillFuel(int amount = 10) {
        fuel += amount;
        if (fuel > INITIAL_FUEL) fuel = INITIAL_FUEL; // Stop at maximum fuel
    }

    // Function to add to earnings
    void addEarnings(float amount) {
        earnings += amount; // Increase earnings by the specified amount
    }

    // Function to draw the Info
    void render() {
        string player = "Driver: " + playerInfo.getName();
        string score = "Score: " + Num2Str(playerInfo.getScore());
    string time = "Elapsed Time: " + Num2Str(gameTime) + " seconds";
    string earningsText = "Earnings: $" + Num2Str((int)earnings); // Convert earnings to string

    // Draw player info, score, time, and earnings on the screen
    DrawString(50, 1150, player, colors[BLACK]);
    DrawString(300, 1150, score, colors[BLACK]);
    DrawString(550, 1150, time, colors[BLACK]);
    DrawString(1000, 1150, earningsText, colors[BLACK]); // Draw earnings text

    // Draw fuel bar background (empty)
    DrawRectangle(FUEL_BAR_X, FUEL_BAR_Y, FUEL_BAR_WIDTH, FUEL_BAR_HEIGHT, colors[GRAY]); // Background
    DrawRectangle(FUEL_BAR_X - 2, FUEL_BAR_Y - 2, FUEL_BAR_WIDTH + 4, FUEL_BAR_HEIGHT + 4, colors[BLACK]); // Border

    // Draw fuel level (filled)
    float fuelRatio = (float)fuel / INITIAL_FUEL;
    int filledWidth = fuelRatio * FUEL_BAR_WIDTH;
    DrawRectangle(FUEL_BAR_X, FUEL_BAR_Y, filledWidth, FUEL_BAR_HEIGHT, colors[RED]); // Fuel level

    // For displaying Insufficient Earnings
    if (nearFuelStation && !isRefueling && earnings <= 0) {
        // Draw text shadow (black, slightly offset)
        DrawString(FUEL_BAR_X + FUEL_BAR_WIDTH / 2 - 90 + 2, FUEL_BAR_Y - 50 - 2, "Insufficient Earnings!", colors[BLACK]);
        // Draw main text (red, centered)
        DrawString(FUEL_BAR_X + FUEL_BAR_WIDTH / 2 - 90, FUEL_BAR_Y - 50, "Insufficient Earnings!", colors[RED]);
        cout << "Insufficient Earnings! at (" << FUEL_BAR_X + FUEL_BAR_WIDTH / 2 - 90 << ", " << FUEL_BAR_Y - 50 << ")" << endl;
    }
}
    
    // Function to reset fuel
    void resetFuel() {
        fuel = INITIAL_FUEL; // Reset fuel to full
    }
    
    // Accessor for Player
    Player& getPlayer() { 
    return playerInfo; 
    }
};

class GameWorld {
private:
    TopInfo* topInfo; // Aggregation: TopInfo exists independently
public:
    GameWorld(TopInfo* ti) : topInfo(ti) {}
    
    void renderWorld() {
        topInfo->render(); // Pass rendering to TopInfo
    }
    
    TopInfo* getTopInfo() { 
    return topInfo; 
    }
};

TopInfo info("Ghafoor"); // Create TopInfo with player name (If somehow name entry process skips, default name is Ghafoor)
GameWorld gameWorld(&info); // Create GameWorld object (Aggregation)

void PlaceNewPassenger() {
    for (int i = 0; i < MAX_PASSENGERS; i++) {
        if (passengers[i].getX() == -1) { // Find an empty slot for a new passenger
            int x, y;
            do {
                x = rand() % 1550 + 50; // Random x position
                y = 50 + rand() % (1120 - 100); // Random y position safely below info bar
            } while (!isPositionValid(x, y, 30, 30)); // Ensure valid position
            passengers[i].setPositionX(x); // Inheritance
            passengers[i].setPositionY(y);
            passengers[i].setDirectionX((rand() % 3) - 1); // Random direction
            passengers[i].setDirectionY((rand() % 3) - 1); // Random direction
            cout << "New passenger placed at (" << x << ", " << y << ")" << endl;
            break; // Exit after placing one new passenger
        }
    }
}

void PlaceNewDelivery() {
    for (int i = 0; i < MAX_DELIVERIES; i++) {
        if (deliveries[i].x == -1) { // Find an empty slot for a new delivery
            int x, y;
            do {
                x = rand() % 1550 + 50; // Random x position
                y = 50 + rand() % (1120 - 100); // Random y position safely below info bar
            } while (!isPositionValid(x, y, 40, 40)); // Ensure valid position
            deliveries[i].x = x;
            deliveries[i].y = y;
            cout << "New delivery placed at (" << x << ", " << y << ")" << endl;
            break; // Exit after placing one new delivery
        }
    }
}

void PickupPassenger(int index) {
    if (driverRole == "Taxi Driver" && !hasPassenger && currentPassengerIndex == -1) {
        hasPassenger = true;
        currentPassengerIndex = index;
        destinationX = passengerDestinations[index].x;
        destinationY = passengerDestinations[index].y;
        pickupTime = gameTime;
        // Remove passenger from map
        passengers[index].setPositionX(-1); // Set position to -1 to indicate it's picked up (Inheritance)
        cout << "Passenger picked up at index " << index << endl;
    }
}


void DropoffPassenger() {
    if (driverRole == "Taxi Driver" && hasPassenger) {
        // Check for collision with other passengers
        for (int i = 0; i < MAX_PASSENGERS; i++) {
            if (passengers[i].getX() != -1 && 
                checkObjectCollision(vehiclePosX, vehiclePosY, 50, 25, 
                                     passengers[i].getX(), passengers[i].getY(), 30, 30)) {
                info.getPlayer().increaseScore(-5); // Deduct 5 points for hitting another passenger (Composition)
                cout << "Hit another passenger! Score deducted: -5" << endl;
                break; // Exit after deducting points
            }
        }
        
        // Drop-off logic
        hasPassenger = false;
        currentPassengerIndex = -1;
        info.getPlayer().increaseScore(10); // Score only for dropoff (Composition)
        info.addEarnings(5); // $5 per drop off
        destinationX = -1;
        destinationY = -1;
        // Place a new passenger after drop-off
        PlaceNewPassenger();
    }
}


void PickupDelivery(int index) {
    if (driverRole == "Delivery Driver" && !hasDelivery && currentDeliveryIndex == -1) {
        hasDelivery = true;
        currentDeliveryIndex = index;
        destinationX = deliveryDestinations[index].x;
        destinationY = deliveryDestinations[index].y;
        pickupTime = gameTime;
        // Remove delivery from map
        deliveries[index].x = -1; // Set position to -1 to indicate it's picked up
        cout << "Delivery picked up at index " << index << endl;
    }
}


void DropoffDelivery() {
    if (driverRole == "Delivery Driver" && hasDelivery) {
        // Check for collision with other delivery boxes
        for (int i = 0; i < MAX_DELIVERIES; i++) {
            if (deliveries[i].x != -1 && 
                checkObjectCollision(vehiclePosX, vehiclePosY, 50, 25, 
                                     deliveries[i].x, deliveries[i].y, 40, 40)) {
                info.getPlayer().increaseScore(-4); // Deduct 4 points for hitting another delivery box (Composition)
                cout << "Hit another delivery box! Score deducted: -4" << endl;
                break; // Exit after deducting points
            }
        }
        
        // Drop-off logic
        hasDelivery = false;
        currentDeliveryIndex = -1;
        info.getPlayer().increaseScore(20); // Score only for dropoff (Composition)
        info.addEarnings(6); // $6 per drop off
        destinationX = -1;
        destinationY = -1;
        // Place a new delivery after drop-off
        PlaceNewDelivery();
    }
}



void UpdateNPCs() {
    // Update car positions
    for (int i = 0; i < MAX_CARS; i++) {
        // Calculate new position based on current direction
        int newX = cars[i].getX() + cars[i].getDirX() * NPC_MOVE_SPEED;
        int newY = cars[i].getY() + cars[i].getDirY() * NPC_MOVE_SPEED;

        // Check for collisions with screen boundaries and buildings
        bool collision = checkScreenBoundary(newX, newY) || checkBuildingCollision(newX, newY);

        // Check for collisions with other cars
        for (int j = 0; j < MAX_CARS && !collision; j++) {
            if (i != j) { // Avoid checking the car against itself
                if (checkObjectCollision(newX, newY, 50, 25, cars[j].getX(), cars[j].getY(), 50, 25)) {
                    collision = true;
                }
            }
        }
        
        // Check for collisions with trees
        for (int j = 0; j < MAX_TREES && !collision; j++) {
            if (checkObjectCollision(newX, newY, 50, 25, trees[j].x, trees[j].y, 20, 40)) {
                collision = true;
            }
        }

        // Check for collisions with delivery pickups
        for (int j = 0; j < MAX_DELIVERIES && !collision; j++) {
            if (checkObjectCollision(newX, newY, 50, 25, deliveries[j].x, deliveries[j].y, 40, 40)) {
                collision = true;
            }
        }

        // Check for collisions with fuel stations
        for (int j = 0; j < MAX_FUEL_STATIONS && !collision; j++) {
            if (checkObjectCollision(newX, newY, 50, 25, fuelStations[j].x, fuelStations[j].y, 30, 60)) {
                collision = true;
            }
        }

        // Check for collision with garage
        if (!collision && checkObjectCollision(newX, newY, 50, 25, garage.x, garage.y, 60, 60)) {
            collision = true;
        }
        
        // Check for collision with player's car
        if (!collision && checkObjectCollision(newX, newY, 50, 25, vehiclePosX, vehiclePosY, 50, 25)) {
            collision = true;
            // Trigger player's car collision effect
            collisionEffectActive = true;
            collisionEffectDuration = COLLISION_EFFECT_TIME;
            // Deduct points based on role
            if (driverRole == "Taxi Driver") {
                info.getPlayer().increaseScore(-3); // Composition
            } else if (driverRole == "Delivery Driver") {
                info.getPlayer().increaseScore(-5); // Composition
            }
            cout << "Player car collision with NPC car! Score: " << info.getPlayer().getScore() << endl;
        }

        // Check for collisions with passengers
        for (int j = 0; j < MAX_PASSENGERS && !collision; j++) {
            if (checkObjectCollision(newX, newY, 50, 25, passengers[j].getX(), passengers[j].getY(), 30, 30)) {
                collision = true;
            }
        }

        if (collision) {
            // Change direction if collision occurs
            cars[i].setDirectionX((rand() % 3) - 1); // New random direction (Inheritance)
            cars[i].setDirectionY((rand() % 3) - 1); // New random direction

            // Ensure the new direction is not zero (to avoid stopping)
            while (cars[i].getDirX() == 0 && cars[i].getDirY() == 0) {
                cars[i].setDirectionX((rand() % 3) - 1); // New random direction (Inheritance)
            	cars[i].setDirectionY((rand() % 3) - 1); // Reassign until it's not zero
            }
        } else {
            // Move the car if no collision
            cars[i].setPositionX(newX);
            cars[i].setPositionY(newY);
        }
    }
    
        // Update passenger positions
    for (int i = 0; i < MAX_PASSENGERS; i++) {
        if (passengers[i].getX() == -1) continue; // Skip if passenger is picked up
        if (driverRole == "Taxi Driver") continue; // Skip movement for Taxi Driver role

        // Calculate new position based on current direction
        int newX = passengers[i].getX() + passengers[i].getDirX() * NPC_MOVE_SPEED;
        int newY = passengers[i].getY() + passengers[i].getDirY() * NPC_MOVE_SPEED;

        // Check for collisions with screen boundaries and buildings
        bool collision = checkScreenBoundary(newX, newY) || checkBuildingCollision(newX, newY);

        // Check for collisions with cars
        for (int j = 0; j < MAX_CARS && !collision; j++) {
            if (checkObjectCollision(newX, newY, 30, 30, cars[j].getX(), cars[j].getY(), 50, 25)) {
                collision = true;
            }
        }

        // Check for collisions with trees
        for (int j = 0; j < MAX_TREES && !collision; j++) {
            if (checkObjectCollision(newX, newY, 30, 30, trees[j].x, trees[j].y, 20, 40)) {
                collision = true;
            }
        }

        // Check for collisions with delivery pickups
        for (int j = 0; j < MAX_DELIVERIES && !collision; j++) {
            if (deliveries[j].x != -1 && checkObjectCollision(newX, newY, 30, 30, deliveries[j].x, deliveries[j].y, 40, 40)) {
                collision = true;
            }
        }

        // Check for collisions with fuel stations
        for (int j = 0; j < MAX_FUEL_STATIONS && !collision; j++) {
            if (checkObjectCollision(newX, newY, 30, 30, fuelStations[j].x, fuelStations[j].y, 30, 60)) {
                collision = true;
            }
        }

        // Check for collision with garage
        if (!collision && checkObjectCollision(newX, newY, 30, 30, garage.x, garage.y, 60, 60)) {
            collision = true;
        }

        // Check for collisions with other passengers
        for (int j = 0; j < MAX_PASSENGERS && !collision; j++) {
            if (i != j && passengers[j].getX() != -1 && 
                checkObjectCollision(newX, newY, 30, 30, passengers[j].getX(), passengers[j].getY(), 30, 30)) {
                collision = true;
            }
        }

        // Check for collision with player's car
        if (!collision && checkObjectCollision(newX, newY, 30, 30, vehiclePosX, vehiclePosY, 50, 25)) {
            collision = true;
            if (driverRole == "Delivery Driver") {
                info.getPlayer().increaseScore(-8); // Deduct 8 points for hitting a passenger (Composition)
                cout << "Hit a passenger! Score deducted: -8" << endl;
            }
        }

        if (collision) {
            // Change direction if collision occurs
            passengers[i].setDirectionX((rand() % 3) - 1); // New random direction (Inheritance)
            passengers[i].setDirectionY((rand() % 3) - 1); // New random direction

            // Ensure the new direction is not zero (to avoid stopping)
            while (passengers[i].getDirX() == 0 && passengers[i].getDirY() == 0) {
                passengers[i].setDirectionX((rand() % 3) - 1); // New random direction (Inheritance)
            	passengers[i].setDirectionY((rand() % 3) - 1); // Reassign until it's not zero
            }
        } else {
            // Move the passenger if no collision
            passengers[i].setPositionX(newX);
            passengers[i].setPositionY(newY);
        }
    }
}

class GameMenu {
private:
    int menuState;

public:
    GameMenu() {
        menuState = 0;
    }

    void setMenuState(int state) {
        menuState = state;
    }

    int getMenuState() {
        return menuState;
    }

    void drawBackground() {
        // Gradient background (Teal)
        for(int y = 0; y < 1200; y++) {
            float ratio = y/1200.0f;
            float r = 0.1f + ratio * 0.2f; // Teal
            float g = 0.2f + ratio * 0.6f;
            float b = 0.4f + ratio * 0.4f;
            float color[] = {r, g, b};
            DrawLine(0, y, 1600, y, 1, color);
        }
        
        // Decorative elements
        DrawRectangle(0, 0, 1600, 1200, colors[BLACK]); // Border
        DrawRectangle(50, 50, 1500, 1100, colors[SKY_BLUE]); // Inner glow effect
    }

    void renderMenu() {
        drawBackground();
        
        // Semi-transparent menu panel
        float panelColor[] = {0.1f, 0.1f, 0.2f, 0.7f}; // Dark with transparency
        DrawRoundRect(400, 300, 800, 600, panelColor, 20.0);

        if (menuState == 0) {
            // Main Menu
            // Title with subtle shadow
            DrawString(580, 850, "RUSH HOUR CHALLENGE", colors[GOLDEN_ROD]);
            DrawString(582, 848, "RUSH HOUR CHALLENGE", colors[BLACK]);
            DrawString(600, 700, "1. START NEW GAME", colors[LIGHT_GRAY]);
            DrawString(600, 600, "2. LEADERBOARD", colors[LIGHT_GRAY]);
            DrawString(600, 500, "3. INSTRUCTIONS", colors[LIGHT_GRAY]);
            DrawString(600, 400, "4. EXIT GAME", colors[LIGHT_GRAY]);
            DrawString(550, 200, "Use number keys (0-4) to navigate", colors[BLACK]);
            
        } else if (menuState == 2) {
            // Leaderboard
            DrawString(580, 850, "LEADERBOARD", colors[GOLDEN_ROD]);
            LoadHighScores();
            for (int i = 0; i < currentScoreCount && i < 10; i++) {
                string entry = to_string(i+1) + ". " + scoreBoard[i].player + " - " + Num2Str(scoreBoard[i].score);
                DrawString(450, 780 - i*50, entry, colors[LIGHT_GRAY]);
            }
            DrawString(650, 200, "0. RETURN TO MAIN MENU", colors[BLACK]);
            
        } else if (menuState == 3) {
            // Instructions
            DrawString(580, 850, "INSTRUCTIONS", colors[GOLDEN_ROD]);
            DrawString(450, 750, "Use arrow keys to move", colors[LIGHT_GRAY]);
            DrawString(450, 700, "Collect passengers/packages", colors[LIGHT_GRAY]);
            DrawString(450, 650, "Manage your fuel carefully", colors[LIGHT_GRAY]);
            DrawString(450, 600, "Complete deliveries before time runs out!", colors[LIGHT_GRAY]);
            DrawString(650, 200, "0. RETURN TO MAIN MENU", colors[BLACK]);
            
        } else if (menuState == 4) {
            // Name entry
            DrawString(580, 850, "ENTER YOUR NAME", colors[GOLDEN_ROD]);
            DrawRoundRect(500, 600, 600, 60, colors[WHITE], 10.0);
            DrawString(520, 620, userName, colors[BLACK]);
            DrawString(650, 200, "0. RETURN TO MAIN MENU", colors[BLACK]);
            
        } else if (menuState == 5) {
            // Role selection
            DrawString(580, 850, "SELECT ROLE", colors[GOLDEN_ROD]);
            DrawString(450, 750, "T - Taxi Driver", colors[GOLD]);
            DrawString(450, 700, "D - Delivery Driver", colors[WHITE]);
            DrawString(450, 650, "R - Random Role", colors[PURPLE]);
            DrawString(650, 200, "0. RETURN TO MAIN MENU", colors[BLACK]);
            
        } else if (menuState == 6) {
            // Role switch menu at garage
            DrawString(580, 850, "SWITCH ROLE", colors[GOLDEN_ROD]);
            DrawString(450, 750, "T - Taxi Driver", colors[GOLD]);
            DrawString(450, 700, "D - Delivery Driver", colors[WHITE]);
            DrawString(450, 650, "R - Random Role", colors[PURPLE]);
            DrawString(650, 200, "Press T, D, or R to switch role", colors[BLACK]);
        }
        
        else if (menuState == 7) {
    	// Win Menu
    	drawBackground();

    	// Semi-transparent celebratory panel with rounded edges
    	float panelColor[] = {0.0f, 0.4f, 0.6f, 0.8f}; // Teal with transparency
    	DrawRoundRect(350, 250, 900, 700, panelColor, 30.0);

    	// Congratulatory message with shadow effect
    	DrawString(480, 900, "CONGRATULATIONS, CHAMPION!", colors[GOLDEN_ROD]);
    	DrawString(482, 898, "CONGRATULATIONS, CHAMPION!", colors[BLACK]);

    	// Display player's name and score
    	string winMessage = "Driver: " + info.getPlayer().getName() + " scored " + Num2Str(info.getPlayer().getScore()) + " points!";
    	DrawString(450, 750, winMessage, colors[WHITE]);

    	// Fun celebratory text
    	DrawString(450, 650, "You're the King of the Roads!", colors[LIGHT_GRAY]);
    	DrawString(450, 600, "Your name will shine on the Leaderboard!", colors[LIGHT_GRAY]);

    	// Animated confetti effect (simple colored dots)
    	for (int i = 0; i < 50; i++) {
        	int confettiX = rand() % 900 + 350; // Random x within panel
        	int confettiY = rand() % 700 + 250; // Random y within panel
        	float confettiColor[] = {rand() % 2, rand() % 2, rand() % 2}; // Random RGB
        	DrawCircle(confettiX, confettiY, 5, confettiColor); // Small confetti dots
    	}

    	// Instruction to exit
    	DrawString(550, 350, "Press any key to exit and save your score!", colors[WHITE]);
	}
    }
};

GameMenu mainMenu; // Create menu object

// Function to draw the game board
void DrawGameBoard() {
    // === Info Bar Separator ===
    DrawRectangle(0, 1120, 1600, 5, colors[GOLDEN_ROD]);
    
    DrawRectangle(230, 970, 50, 150, colors[BLACK]);
    DrawRectangle(200, 920, 200, 70, colors[BLACK]);
    DrawRectangle(200, 350, 150, 250, colors[BLACK]);
    DrawRectangle(530, 260, 400, 50, colors[BLACK]);
    DrawRectangle(1320, 350, 280, 50, colors[BLACK]);
    DrawRectangle(730, 600, 50, 100, colors[BLACK]);
    DrawRectangle(1050, 170, 60, 600, colors[BLACK]);
    DrawRectangle(250, 0, 50, 120, colors[BLACK]);
    DrawRectangle(700, 0, 50, 120, colors[BLACK]);
    DrawRectangle(1450, 0, 50, 120, colors[BLACK]);
    DrawRectangle(460, 450, 75, 400, colors[BLACK]);
    DrawRectangle(600, 920, 1000, 70, colors[BLACK]);
    DrawRectangle(1050, 500, 300, 70, colors[BLACK]);
}

// Function to check for fuel station proximity (nearness) and handle refueling
void CheckFuelStationProximity() {
    nearFuelStation = false; // Reset flag
    for (int i = 0; i < MAX_FUEL_STATIONS; i++) {
        if (checkObjectCollision(vehiclePosX, vehiclePosY, 50, 25, fuelStations[i].x, fuelStations[i].y, 30, 60)) {
            nearFuelStation = true; // Set flag when near a fuel station
            if (earnings > 0 && info.getFuel() < INITIAL_FUEL) {
                isRefueling = true;
                info.refillFuel(2); // Refuel by 2 units per frame
                earnings -= 0.01; // Deduct $0.01 from earnings for refueling
                cout << "Refueling at fuel station! Fuel: " << info.getFuel() << " Earnings: $" << earnings << endl;
            } else {
                isRefueling = false;
                if (earnings <= 0) {
                    cout << "Cannot refuel: Earnings are $0 or less!" << endl;
                } else {
                    cout << "Fuel tank full! No further refueling needed." << endl;
                }
            }
            break;
        }
    }
    if (!nearFuelStation) {
        isRefueling = false; // Stop refueling if not near a fuel station
    }
}


// Function to display the game
void GameDisplay() {
    glClearColor(1, 1, 1, 0);
    glClear(GL_COLOR_BUFFER_BIT);

    if (mainMenu.getMenuState() == 0 || mainMenu.getMenuState() == 2 || mainMenu.getMenuState() == 3 || 
        mainMenu.getMenuState() == 4 || mainMenu.getMenuState() == 5 || mainMenu.getMenuState() == 6 ||
        mainMenu.getMenuState() == 7) {
        mainMenu.renderMenu();
        glutSwapBuffers();
    } else if (mainMenu.getMenuState() == 1) {
        if (!gameElementsInitialized) {
            InitializeGameElements();
            gameElementsInitialized = true;
        }
        UpdateNPCs();
        CheckFuelStationProximity();
        if (info.getPlayer().getScore() >= 100) {
            cout << "Congratulations! You won by scoring 100 points!" << endl;
            AddHighScore(info.getPlayer().getName(), info.getPlayer().getScore()); // Composition
            mainMenu.setMenuState(7);
            glutPostRedisplay();
            return;
        }
        if (gameTime >= 180) {
            cout << "Game Over! Time's up." << endl;
            AddHighScore(info.getPlayer().getName(), info.getPlayer().getScore()); // Composition
            exit(0);
        }
        if (info.getPlayer().getScore() < 0) {
    	cout << "Game Over! Score below zero." << endl;
    	AddHighScore(info.getPlayer().getName(), info.getPlayer().getScore()); // Composition
    	exit(0);
	}
	
        DrawGameBoard();
        gameWorld.renderWorld(); // Aggregation
        renderVehicle();
        renderGameElements();
        glutSwapBuffers();
    }
}

// Function to handle non-printable key presses
void NonPrintableKeys(int key, int x, int y) {
    if (mainMenu.getMenuState() == 1) {
        if (info.getFuel() <= 0) {
            // Game over - Exit
            cout << "Game Over! Fuel depleted." << endl;
            AddHighScore(info.getPlayer().getName(), info.getPlayer().getScore()); // Composition
            exit(0);
        }

        int previousPosX = vehiclePosX;
        int previousPosY = vehiclePosY;
        int moveX = 0, moveY = 0;

        if (key == GLUT_KEY_LEFT) {
            moveX -= 10;
        } else if (key == GLUT_KEY_RIGHT) {
            moveX += 10;
        } else if (key == GLUT_KEY_UP) {
            moveY += 10;
        } else if (key == GLUT_KEY_DOWN) {
            moveY -= 10;
        }
        
        vehiclePosX += moveX;
        vehiclePosY += moveY;

        // Collision Logic
        bool hitScreen = checkScreenBoundary(vehiclePosX, vehiclePosY);
        bool hitBuilding = checkBuildingCollision(vehiclePosX, vehiclePosY);
        bool hitCar = false;
        bool hitTree = false;
        bool hitGarage = false;
        bool hitPassenger = false; // Track passenger collision
        bool hitDelivery = false;  // Track delivery collision

        // Check for collisions with NPC cars
        for (int i = 0; i < MAX_CARS; i++) {
            if (cars[i].getX() != -1 && checkObjectCollision(vehiclePosX, vehiclePosY, 50, 25, cars[i].getX(), cars[i].getY(), 50, 25)) {
                hitCar = true;
                if (driverRole == "Taxi Driver") {
                    info.getPlayer().increaseScore(-3); // Composition
                } else {
                    info.getPlayer().increaseScore(-5); // Composition
                }
                break;
            }
        }

        // Check for collisions with trees
        for (int i = 0; i < MAX_TREES; i++) {
            if (trees[i].x != -1 && checkObjectCollision(vehiclePosX, vehiclePosY, 50, 25, trees[i].x, trees[i].y, 20, 40)) {
                hitTree = true;
                if (driverRole == "Taxi Driver") {
                    info.getPlayer().increaseScore(-2); // Composition
                } else {
                    info.getPlayer().increaseScore(-4); // Composition
                }
                break;
            }
        }

        // Check for collision with garage
        hitGarage = checkObjectCollision(vehiclePosX, vehiclePosY, 50, 25, garage.x, garage.y, 60, 60);

        // Check for collisions with passengers (Taxi Driver after pickup, Delivery Driver always)
        if (driverRole == "Taxi Driver" && hasPassenger) {
            for (int i = 0; i < MAX_PASSENGERS; i++) {
                if (passengers[i].getX() != -1 && 
                    checkObjectCollision(vehiclePosX, vehiclePosY, 50, 25, passengers[i].getX(), passengers[i].getY(), 30, 30)) {
                    hitPassenger = true;
                    info.getPlayer().increaseScore(-5); // Deduct 5 points for Taxi Driver (Composition)
                    cout << "Hit another passenger! Score deducted: -5" << endl;
                    break;
                }
            }
        } else if (driverRole == "Delivery Driver") {
            for (int i = 0; i < MAX_PASSENGERS; i++) {
                if (passengers[i].getX() != -1 && 
                    checkObjectCollision(vehiclePosX, vehiclePosY, 50, 25, passengers[i].getX(), passengers[i].getY(), 30, 30)) {
                    hitPassenger = true;
                    info.getPlayer().increaseScore(-8); // Deduct 8 points for Delivery Driver (Composition)
                    cout << "Hit a passenger! Score deducted: -8" << endl;
                    break;
                }
            }
        }

        // Check for collisions with delivery boxes (Delivery Driver, after pickup)
        if (driverRole == "Delivery Driver" && hasDelivery) {
            for (int i = 0; i < MAX_DELIVERIES; i++) {
                if (deliveries[i].x != -1 && 
                    checkObjectCollision(vehiclePosX, vehiclePosY, 50, 25, deliveries[i].x, deliveries[i].y, 40, 40)) {
                    hitDelivery = true;
                    info.getPlayer().increaseScore(-4); // Deduct 4 points (Composition)
                    cout << "Hit another delivery box! Score deducted: -4" << endl;
                    break;
                }
            }
        }

        // Handle collisions
        if (hitScreen) {
            vehiclePosX = previousPosX;
            vehiclePosY = previousPosY;
        } 
        else if (hitBuilding || hitCar || hitTree || hitPassenger || hitDelivery) {
            vehiclePosX = previousPosX - moveX * 3; // Distance of bouncing back
            vehiclePosY = previousPosY - moveY * 3;
            collisionEffectActive = true;
            collisionEffectDuration = COLLISION_EFFECT_TIME;
            
            if (hitBuilding) {
                if (driverRole == "Taxi Driver") {
                    info.getPlayer().increaseScore(-2); // (Composition)
                } else {
                    info.getPlayer().increaseScore(-4); // (Composition)
                }
            }
        }
        
        if (!isRefueling) {
            info.consumeFuel(1); // Consume fuel only if not refueling
        }
    }
    updateVehiclePosition();
    glutPostRedisplay();
}

// Function to handle printable key presses
void PrintableKeys(unsigned char key, int x, int y) {
    if (key == 27) {
        exit(1); // Exit the program when escape key is pressed
    }

    if (mainMenu.getMenuState() == 4) {
        // Entering name
        if (key == 13 || key == 10) { // Enter key
            if (userName.length() > 0) {
                info.getPlayer().reset(userName); // Reset player with new name (Composition)
                mainMenu.setMenuState(5); // Move to role selection
            }
        } else if (key == 8 || key == 127) { // Backspace
            if (!userName.empty())
                userName.pop_back(); // Remove last character
        } else {
            if (userName.length() < 20)
                userName += key; // Add character to name
        }
    } else if (mainMenu.getMenuState() == 5) {
        // Initial Role Selection
        if (key == 't' || key == 'T') {
            driverRole = "Taxi Driver"; // Set role to Taxi Driver
            mainMenu.setMenuState(1); // Start game
            gameTime = 0; // Reset time
            info.resetFuel(); // Reset fuel
            gameElementsInitialized = false; // Reset to allow reinitialization
        } else if (key == 'd' || key == 'D') {
            driverRole = "Delivery Driver"; // Set role to Delivery Driver
            mainMenu.setMenuState(1); // Start game
            gameTime = 0; // Reset time
            info.resetFuel(); // Reset fuel
            gameElementsInitialized = false; // Reset to allow reinitialization
        } else if (key == 'r' || key == 'R') {
            driverRole = (rand() % 2 == 0) ? "Taxi Driver" : "Delivery Driver"; // Randomly select role
            mainMenu.setMenuState(1); // Start game
            gameTime = 0; // Reset time
            info.resetFuel(); // Reset fuel
            gameElementsInitialized = false; // Reset to allow reinitialization
        }
    } else if (mainMenu.getMenuState() == 1) {
        // In-game, check for Spacebar for pickup/drop-off
        if (key == 32) { // Spacebar key
            // Taxi Driver - Passenger Pickup
            if (driverRole == "Taxi Driver" && !hasPassenger) {
                for (int i = 0; i < MAX_PASSENGERS; i++) {
                    if (passengers[i].getX() != -1 && 
                        checkObjectCollision(vehiclePosX, vehiclePosY, 50, 25, 
                                            passengers[i].getX(), passengers[i].getY(), 30, 30)) {
                        PickupPassenger(i);
                        break;
                    }
                }
            }
            
            // Delivery Driver - Package Pickup
            if (driverRole == "Delivery Driver" && !hasDelivery) {
                for (int i = 0; i < MAX_DELIVERIES; i++) {
                    if (deliveries[i].x != -1 && 
                        checkObjectCollision(vehiclePosX, vehiclePosY, 50, 25, 
                                            deliveries[i].x, deliveries[i].y, 40, 40)) {
                        PickupDelivery(i);
                        break;
                    }
                }
            }
            
            // Dropoff Handling
            if ((hasPassenger || hasDelivery) && destinationX != -1) {
                if (checkObjectCollision(vehiclePosX, vehiclePosY, 50, 25, 
                                        destinationX, destinationY, 40, 40)) {
                    if (hasPassenger) DropoffPassenger();
                    if (hasDelivery) DropoffDelivery();
                }
            }
        }
        // In-game, check for garage role switch
        if ((key == 'p' || key == 'P') && 
            checkObjectCollision(vehiclePosX, vehiclePosY, 50, 25, garage.x, garage.y, 60, 60)) {
            mainMenu.setMenuState(6); // Open role switch menu
        }
    } else if (mainMenu.getMenuState() == 6) {
        // Role Switch Menu
        if (key == 't' || key == 'T') {
            driverRole = "Taxi Driver"; // Switch to Taxi Driver
            mainMenu.setMenuState(1); // Resume game
            gameElementsInitialized = false; // Force reinitialization of game elements
            InitializeGameElements(); // Update map immediately
            info.resetFuel(); // Reset fuel to full
            earnings = 0; // Reset earnings to 0
            info.getPlayer().increaseScore(-info.getPlayer().getScore()); // Reset score to 0 (Composition)
            gameTime = 0; // Reset elapsed time to 0
        } else if (key == 'd' || key == 'D') {
            driverRole = "Delivery Driver"; // Switch to Delivery Driver
            mainMenu.setMenuState(1); // Resume game
            gameElementsInitialized = false; // Force reinitialization of game elements
            InitializeGameElements(); // Update map immediately
            info.resetFuel(); // Reset fuel to full
            earnings = 0; // Reset earnings to 0
            info.getPlayer().increaseScore(-info.getPlayer().getScore()); // Reset score to 0 (Composition)
            gameTime = 0; // Reset elapsed time to 0
        } else if (key == 'r' || key == 'R') {
            driverRole = (rand() % 2 == 0) ? "Taxi Driver" : "Delivery Driver"; // Randomly select role
            mainMenu.setMenuState(1); // Resume game
            gameElementsInitialized = false; // Force reinitialization of game elements
            InitializeGameElements(); // Update map immediately
            info.resetFuel(); // Reset fuel to full
            earnings = 0; // Reset earnings to 0
            info.getPlayer().increaseScore(-info.getPlayer().getScore()); // Reset score to 0 (Composition)
            gameTime = 0; // Reset elapsed time to 0
        }
    } else if (mainMenu.getMenuState() == 7) {
        // Win menu: any key exits the game
        AddHighScore(info.getPlayer().getName(), info.getPlayer().getScore()); // Ensure score is saved
        exit(0); // Exit the game
    }

    // Menu navigation
    if (key == '1') {
        mainMenu.setMenuState(4); // Go to name entry
    }
    if (key == '2') {
        mainMenu.setMenuState(2); // Go to high scores
    }
    if (key == '3') {
        mainMenu.setMenuState(3); // Go to help
    }
    if (key == '4') {
        exit(0); // Exit the game
    }
    if (key == '0') {
        mainMenu.setMenuState(0); // Return to main menu
    }

    glutPostRedisplay(); // Request to redraw the window
}

// Timer function to update game state
void Timer(int m) {
    if (mainMenu.getMenuState() == 1) {
        if (gameTime < 180) {
            gameTime += 1.0;
        }
        if (collisionEffectActive) {
            collisionEffectDuration--;
            if (collisionEffectDuration <= 0) {
                collisionEffectActive = false;
            }
        }
        if ((hasPassenger || hasDelivery) && (gameTime - pickupTime) > MAX_DELIVERY_TIME) { // If not delivered in 30 seconds
            if (hasPassenger) {
                info.getPlayer().increaseScore(-10); // Composition
                hasPassenger = false;
                currentPassengerIndex = -1;
                destinationX = -1;
                destinationY = -1;
            }
            if (hasDelivery) {
                info.getPlayer().increaseScore(-15); // Composition
                hasDelivery = false;
                currentDeliveryIndex = -1;
                destinationX = -1;
                destinationY = -1;
            }
        }
        glutPostRedisplay();
    }
    glutTimerFunc(1000, Timer, 0);
}

// Mouse event handling functions
void MousePressedAndMoved(int x, int y) {
    cout << x << " " << y << endl; // Print mouse position
    glutPostRedisplay(); // Request to redraw the window
}

void MouseMoved(int x, int y) {
    glutPostRedisplay(); // Request to redraw the window
}

void MouseClicked(int button, int state, int x, int y) {
    if (button == GLUT_LEFT_BUTTON) {
        cout << GLUT_DOWN << " " << GLUT_UP << endl; // Print button state
    } else if (button == GLUT_RIGHT_BUTTON) {
        cout << "Right Button Pressed" << endl; // Print right button press
    }
    glutPostRedisplay(); // Request to redraw the window
}

// Main function
int main(int argc, char* argv[]) {
    int windowWidth = 1600, windowHeight = 1200; // Set window size

    InitRandomizer(); // Seed the random number generator
    glutInit(&argc, argv); // Initialize the graphics library
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA); // Set display mode
    glutInitWindowPosition(50, 50); // Set initial window position
    glutInitWindowSize(windowWidth, windowHeight); // Set window size
    glutCreateWindow("Rush Hour Game"); // Create window with title
    SetCanvasSize(windowWidth, windowHeight); // Set canvas size

    // Register functions with the library
    glutDisplayFunc(GameDisplay); // Set display function
    glutSpecialFunc(NonPrintableKeys); // Set non-printable key function
    glutKeyboardFunc(PrintableKeys); // Set printable key function
    glutTimerFunc(1000.0, Timer, 0); // Set timer function

    glutMouseFunc(MouseClicked); // Set mouse click function
    glutPassiveMotionFunc(MouseMoved); // Set mouse move function
    glutMotionFunc(MousePressedAndMoved); // Set mouse pressed and moved function

    glutMainLoop(); // Enter the main loop
    return 1; // Return success
}
#endif /* RushHour_CPP_ */
